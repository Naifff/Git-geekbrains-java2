package ru.geekbrains.java2.lesson2;

import ru.geekbrains.java2.lesson1.Car;

/**
 * Created by i on 17.11.2017.
 */
public class Lada extends Car {


    public Lada() {
        name2 = "rwer";

    }
}
