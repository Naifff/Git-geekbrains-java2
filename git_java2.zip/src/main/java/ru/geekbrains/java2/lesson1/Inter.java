package ru.geekbrains.java2.lesson1;

/**
 * Created by Home-pc on 18.08.2016.
 */
public interface Inter extends Jumpable, Swimable {

}
