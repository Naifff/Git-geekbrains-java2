package ru.geekbrains.java2.lesson1; /**
 */
public interface Jumpable {
    String NAME = null;
    public static final String TITLE = "huuh";
    void jump(float height);
}
