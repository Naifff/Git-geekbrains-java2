package ru.geekbrains.java2.dz.dz1.RoumyantsevPA; /**
 */
public interface Swimable {
    void swim(float dist);
}
