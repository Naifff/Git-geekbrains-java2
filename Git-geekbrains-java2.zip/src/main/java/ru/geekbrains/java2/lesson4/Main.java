package ru.geekbrains.java2.lesson4;

/**
 * Created by Home-pc on 29.08.2016.
 */
public class Main {
    public static void main(String[] args) {
        Win win = new Win();

    }
}
