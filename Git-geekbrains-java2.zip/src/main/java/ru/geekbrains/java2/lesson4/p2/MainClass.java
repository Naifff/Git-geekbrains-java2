package ru.geekbrains.java2.lesson4.p2;


public class MainClass {
    public static void main(String[] args) {
        Form1 w = new Form1();
    }

}
