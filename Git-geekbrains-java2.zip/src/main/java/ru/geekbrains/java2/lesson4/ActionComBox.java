package ru.geekbrains.java2.lesson4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Home-pc on 24.03.2017.
 */
public class ActionComBox implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("!!!@@###");
    }
}
