package ru.geekbrains.java2.lesson4.p2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by i on 27.11.2017.
 */
public class Form2 {
    private JButton buttonкурнеButton;
    private JTable table1;
    private JTabbedPane tabbedPane1;

    public Form2() {
        buttonкурнеButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }
}
