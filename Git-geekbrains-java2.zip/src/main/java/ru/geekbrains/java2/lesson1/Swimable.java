package ru.geekbrains.java2.lesson1; /**
 */
public interface Swimable {
    void swim(float dist);
}
