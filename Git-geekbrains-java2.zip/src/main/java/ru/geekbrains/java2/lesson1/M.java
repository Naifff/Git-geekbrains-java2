package ru.geekbrains.java2.lesson1;

import java.util.Arrays;

/**
 * Created by Home-pc on 28.09.2016.
 */
public class M {
    public static void main(String[] args) {
        Car car = new Car();
        Car car1 = new Car("gf", "fhf");
        Car car2 = new Car("gf");
        String s = "hj";
        String s1 = new String("hj");
        Arrays.toString(new int[2]);


    }
}
