package ru.geekbrains.java2.lesson1.en;


public enum  Fruit {
    ORANGE, APPLE, BANANA, CHERRY
}
