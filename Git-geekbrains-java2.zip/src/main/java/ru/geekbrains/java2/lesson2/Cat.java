package ru.geekbrains.java2.lesson2;
public class Cat {
    private String name;

    public void info() {
        System.out.println("Cat: " + name);
    }
}
