package ru.geekbrains.java2.lesson2;

import ru.geekbrains.java2.lesson1.Car;

/**
 * Created by i on 17.11.2017.
 */
public class Main {
    public static void main(String[] args) {
        Car car = new Car();
//        String s = car.name3;
//        String s2 = car.name2;
    }
}
