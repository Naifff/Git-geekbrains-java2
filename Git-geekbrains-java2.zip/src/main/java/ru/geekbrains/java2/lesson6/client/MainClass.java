package ru.geekbrains.java2.lesson6.client;

public class MainClass {
    public static void main(String[] args) {
        MyWindow w = new MyWindow();
    }
}
