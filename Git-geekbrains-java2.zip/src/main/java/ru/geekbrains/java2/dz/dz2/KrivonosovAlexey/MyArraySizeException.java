package ru.geekbrains.java2.dz.dz2.KrivonosovAlexey;

public class MyArraySizeException extends IndexOutOfBoundsException {

    public MyArraySizeException(String message){
        super(message);
    }
}
