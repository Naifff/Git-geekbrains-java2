package ru.geekbrains.java2.dz.dz1.RustamMuftakhov;

public class Obstacle {

    protected String name;
    protected int obstacleParameter;

    public Obstacle(String name, int obstacleParameter){

        this.name = name;
        this.obstacleParameter = obstacleParameter;

    }

}
