package ru.geekbrains.java2.dz.dz1.FedulovMS.AnimalRaces;

public interface Flyable {
    boolean fly_f(double dist);
    boolean fly_h(double height);
}
