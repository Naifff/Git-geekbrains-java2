package ru.geekbrains.java2.dz.dz4.KrivonosovAlexey;

import javax.swing.*;

public class Properities extends JFrame {
    public Properities(){

    }
}
