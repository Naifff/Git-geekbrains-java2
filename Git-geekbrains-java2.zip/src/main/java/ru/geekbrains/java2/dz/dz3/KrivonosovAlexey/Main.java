package ru.geekbrains.java2.dz.dz3.KrivonosovAlexey;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        FlightTable fl1 = new FlightTable();
        fl1.initFlightTable();
        fl1.printFlightTable();
    }
}
