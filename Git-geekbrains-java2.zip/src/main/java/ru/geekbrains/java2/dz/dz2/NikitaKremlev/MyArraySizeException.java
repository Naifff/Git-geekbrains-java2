package ru.geekbrains.java2.dz.dz2.NikitaKremlev;

public class MyArraySizeException extends Exception {
    public MyArraySizeException() {
        super();
    }

    public MyArraySizeException(String message) {
        super(message);
    }
}
