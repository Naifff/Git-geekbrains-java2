package ru.geekbrains.java2.dz.dz6.AndreyMurzin;

public class StartClient {
    public static void main(String[] args) {
        Client.startClient();
    }
}
