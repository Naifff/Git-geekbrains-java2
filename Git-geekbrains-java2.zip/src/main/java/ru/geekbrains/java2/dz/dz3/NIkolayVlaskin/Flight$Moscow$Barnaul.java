package ru.geekbrains.java2.dz.dz3.NIkolayVlaskin;


public class Flight$Moscow$Barnaul extends Flight {

    public Flight$Moscow$Barnaul() {
        setNameFlight("Flight number 1: Moscow - Barnaul");
    }
}
