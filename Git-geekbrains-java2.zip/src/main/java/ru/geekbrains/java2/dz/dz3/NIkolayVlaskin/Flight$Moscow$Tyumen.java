package ru.geekbrains.java2.dz.dz3.NIkolayVlaskin;


public class Flight$Moscow$Tyumen extends Flight {

    public Flight$Moscow$Tyumen() {
        setNameFlight("Flight number 2: Moscow - Tymen");
    }

}
