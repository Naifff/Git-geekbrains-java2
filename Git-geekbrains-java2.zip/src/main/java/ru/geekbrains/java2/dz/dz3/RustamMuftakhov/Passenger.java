package ru.geekbrains.java2.dz.dz3.RustamMuftakhov;

public class Passenger {

    private String name;
    private int doc;

    public void setDoc(int doc) {
        this.doc = doc;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDoc() {
        return doc;
    }

    public String getName() {
        return name;
    }

}
