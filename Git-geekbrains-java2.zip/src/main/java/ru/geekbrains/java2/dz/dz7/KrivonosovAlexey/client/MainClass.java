package ru.geekbrains.java2.dz.dz7.KrivonosovAlexey.client;
public class MainClass {
    public static void main(String[] args) {
        MyWindow w = new MyWindow();
    }
}
