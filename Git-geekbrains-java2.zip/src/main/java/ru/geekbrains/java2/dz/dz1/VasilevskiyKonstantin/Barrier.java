package ru.geekbrains.java2.dz.dz1.VasilevskiyKonstantin;

public class Barrier {
    private String name;
    private int force;

    public Barrier(String name, int force) {
        this.name = name;
        this.force = force;
    }

    public String getName() {
        return name;
    }

    public int getForce() {
        return force;
    }
}
