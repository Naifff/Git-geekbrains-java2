package ru.geekbrains.java2.dz.dz6.SypchenkoAlexey.client;

public class MainClient {
    public static void main(String[] args) {
            ChatWindow chatWindow = new ChatWindow();
    }
}
