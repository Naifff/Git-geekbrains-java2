package ru.geekbrains.java2.dz.dz7.VeretennikovSergey.client;

import ru.geekbrains.java2.lesson7.client.MyWindow;

public class MainClass {
    public static void main(String[] args) {
        MyWindow w = new MyWindow();
    }
}
