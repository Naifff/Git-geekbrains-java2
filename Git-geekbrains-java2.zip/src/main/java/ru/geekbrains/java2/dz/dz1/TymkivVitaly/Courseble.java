package ru.geekbrains.java2.dz.dz1.TymkivVitaly;

/**
 * Created by i on 20.11.2017.
 */
public interface Courseble {
    void dolt(Team team);
    void showResult();
}
