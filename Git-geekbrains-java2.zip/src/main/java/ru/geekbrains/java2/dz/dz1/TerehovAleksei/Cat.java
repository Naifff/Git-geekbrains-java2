package ru.geekbrains.java2.dz.dz1.TerehovAleksei;

public class Cat extends Animal {

    public Cat(String name) {
        super(name);
        maxRunDistance = 800;
        maxSwimDistance = 0;
        maxJumpHeight = 5;
    }
}
