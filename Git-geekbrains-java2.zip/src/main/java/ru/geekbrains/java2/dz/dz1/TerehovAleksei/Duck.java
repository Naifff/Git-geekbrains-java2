package ru.geekbrains.java2.dz.dz1.TerehovAleksei;

public class Duck extends Animal {
    public Duck(String name) {
        super(name);
        maxRunDistance = 300;
        maxSwimDistance = 1000;
        maxJumpHeight = 1;
    }
}
