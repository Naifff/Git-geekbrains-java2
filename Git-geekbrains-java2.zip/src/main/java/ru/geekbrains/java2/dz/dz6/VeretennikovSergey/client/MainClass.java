package ru.geekbrains.java2.dz.dz6.VeretennikovSergey.client;

public class MainClass {
    public static void main(String[] args) {
        MyWindow w = new MyWindow();
    }
}
