package ru.geekbrains.java2.dz.dz2.VeretennikovSergey;

public interface SumArray {
    void SumArray();
  }
