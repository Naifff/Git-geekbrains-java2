package ru.geekbrains.java2.dz.dz4.AlexanderZaychikov;

public class MainClass {

    public static void main(String[] args) {
        Form f = new Form();
      //  f.setVisible(true);

    }
}
