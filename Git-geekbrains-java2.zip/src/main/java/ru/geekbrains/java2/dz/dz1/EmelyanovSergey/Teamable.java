package ru.geekbrains.java2.dz.dz1.EmelyanovSergey;

public interface Teamable {
    void teamResult();
    void teamInfo();
    String getTeamName();
    void goToCource(Courseable c);
}
