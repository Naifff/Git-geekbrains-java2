package ru.geekbrains.java2.dz.dz1.RoumyantsevPA; /**
 */
public interface Jumpable {
//    String NAME = null;
//    public static final String TITLE = "huuh";
    void jump(float height);
}
