package ru.geekbrains.java2.dz.dz2.YagudinAlexey;

public class MyArrayDataException extends Exception {
    public MyArrayDataException(String s){
        super(s);
    }
}
