package ru.geekbrains.java2.dz.dz1.TymkivVitaly;

interface Swim {
    String swim(int dist);
}
