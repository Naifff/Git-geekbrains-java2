package ru.geekbrains.java2.dz.dz8.RoumyantsevPA.cui;

public class Main {
    public static void main(String[] args) {
        MyConsole console = new MyConsole();
    }

}
