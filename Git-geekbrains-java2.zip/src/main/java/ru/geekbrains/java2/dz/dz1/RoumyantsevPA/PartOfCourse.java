package ru.geekbrains.java2.dz.dz1.RoumyantsevPA;

public interface PartOfCourse {
    public abstract void doIt(TeamMember t);
}
