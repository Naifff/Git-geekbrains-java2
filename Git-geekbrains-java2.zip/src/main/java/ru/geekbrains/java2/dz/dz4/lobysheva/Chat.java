package ru.geekbrains.java2.dz.dz4.lobysheva;

/*
 * Created by Oxana Lobysheva on 27/11/2017.
 */

public class Chat {

    public static void main(String[] arg){

        User user = new User();
        MainFrame frame = new MainFrame(user);

    }

}
