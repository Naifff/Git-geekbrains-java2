package ru.geekbrains.java2.dz.dz1.EmelyanovSergey;

/**
 * Created by i on 20.11.2017.
 */
public interface Info {
    void getAllInfo();
}
