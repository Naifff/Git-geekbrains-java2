package ru.geekbrains.java2.dz.dz1.FedulovMS.AnimalRaces;

public interface Jumpable {
    boolean jump(double height);
}
