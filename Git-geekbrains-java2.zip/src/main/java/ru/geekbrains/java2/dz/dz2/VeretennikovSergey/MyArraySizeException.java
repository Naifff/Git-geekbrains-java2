package ru.geekbrains.java2.dz.dz2.VeretennikovSergey;

public class MyArraySizeException extends ClassCastException {

    public MyArraySizeException(){
        super("Ошибка размерности массива");
    }
}
