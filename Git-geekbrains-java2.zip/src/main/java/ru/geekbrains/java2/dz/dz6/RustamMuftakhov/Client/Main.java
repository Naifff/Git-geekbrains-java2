package ru.geekbrains.java2.dz.dz6.RustamMuftakhov.Client;

public class Main {

    public static void main(String[] args) {
        System.out.println("Запуск клиента успешен, набирайте свое сообщение. Чтобы закончить сессию, напишите end session");
        ClientClass clientClass = new ClientClass();
    }


}
