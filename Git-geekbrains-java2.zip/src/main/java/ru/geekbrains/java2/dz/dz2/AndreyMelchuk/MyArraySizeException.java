package ru.geekbrains.java2.dz.dz2.AndreyMelchuk;

public class MyArraySizeException extends Exception {
}
