package ru.geekbrains.java2.dz.dz5.RoumyantsevPA;

public class Runner {
    private int i;

    public void setI(int i) {
        this.i = i;
    }

    public int getI() {
        return i;
    }

    public Runner() {
        this.i = 0;
    }

}

