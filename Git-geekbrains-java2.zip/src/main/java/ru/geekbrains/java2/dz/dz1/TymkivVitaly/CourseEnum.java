package ru.geekbrains.java2.dz.dz1.TymkivVitaly;

/**
 * Created by i on 20.11.2017.
 */
public enum CourseEnum {
    run, swim, go, jump;
}
