package ru.geekbrains.java2.dz.dz2.YagudinAlexey;

public class MyArraySizeException extends Exception {
    public MyArraySizeException(String s){
        super(s);
    }
}
