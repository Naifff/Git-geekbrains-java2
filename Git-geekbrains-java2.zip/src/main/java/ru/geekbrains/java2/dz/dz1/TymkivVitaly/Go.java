package ru.geekbrains.java2.dz.dz1.TymkivVitaly;

interface Go {
    String go(int dist);
}
