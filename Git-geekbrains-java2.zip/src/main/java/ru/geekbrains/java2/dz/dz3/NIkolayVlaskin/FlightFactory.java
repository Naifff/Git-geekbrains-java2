package ru.geekbrains.java2.dz.dz3.NIkolayVlaskin;

public interface FlightFactory {

    Flight$Moscow$Barnaul createFlightMoscowBarnaul();
    Flight$Moscow$Tyumen createFlightMoscowTyumen();
}
