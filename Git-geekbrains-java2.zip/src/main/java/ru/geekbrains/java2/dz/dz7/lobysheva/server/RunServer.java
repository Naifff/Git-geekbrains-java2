package ru.geekbrains.java2.dz.dz7.lobysheva.server;

/*
 * Created by Oxana Lobysheva on 09/12/2017.
 */

public class RunServer {
    public static void main(String[] args) {
        new ChatServer();
    }
}
