package ru.geekbrains.java2.dz.dz1.FedulovMS.AnimalRaces;

public interface Swimable {
    boolean swim(double dist);
}
