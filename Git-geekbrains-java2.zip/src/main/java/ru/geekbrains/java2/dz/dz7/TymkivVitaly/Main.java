package ru.geekbrains.java2.dz.dz7.TymkivVitaly;
//package client;

public class Main {
    public static void main(String[] args) {
        ClientWindow clientWindow = new ClientWindow();
    }
}
