package ru.geekbrains.java2.dz.dz4.SporyninaDariya;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        new Chat();
    }
}
