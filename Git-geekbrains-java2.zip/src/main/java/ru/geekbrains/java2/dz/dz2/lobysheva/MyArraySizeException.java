package ru.geekbrains.java2.dz.dz2.lobysheva;

/*
 * Created by Oxana Lobysheva on 20/11/2017.
 */

public class MyArraySizeException extends MyExceptions {

    public MyArraySizeException(String message){
        super(message);
    }

}
