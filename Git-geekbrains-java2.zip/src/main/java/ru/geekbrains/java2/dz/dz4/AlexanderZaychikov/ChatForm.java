package ru.geekbrains.java2.dz.dz4.AlexanderZaychikov;

import javax.swing.*;

public class ChatForm extends JFrame{
    private JTextArea textArea1;
    private JTextField textField1;
    private JButton отправитьButton;
    private JList list1;

    @Override
    public void setVisible(boolean b) {
        super.setVisible(b);
    }

    public void setData(Form data) {
    }

    public void getData(Form data) {
    }

    public boolean isModified(Form data) {
        return false;
    }
}
