package ru.geekbrains.java2.dz.dz1.TymkivVitaly;

public interface Jump {
    String jump(double dist);
}
