package ru.geekbrains.java2.dz.dz2.NikitaKremlev;

public class MyArrayDataException extends Exception {
    public MyArrayDataException() {
        super();
    }

    public MyArrayDataException(String message) {
        super(message);
    }
}
