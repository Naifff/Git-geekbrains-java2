package ru.geekbrains.java2.dz.dz2.lobysheva;

/*
 * Created by Oxana Lobysheva on 20/11/2017.
 */

public class MyArrayDataException extends MyExceptions {

    public MyArrayDataException(String message){
        super(message);
    }

}
