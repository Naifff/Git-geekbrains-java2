package ru.geekbrains.java2.dz.dz1.TerehovAleksei;

public class Dog extends Animal{

    public Dog(String name) {
        super(name);
        maxRunDistance = 1000;
        maxSwimDistance = 300;
        maxJumpHeight = 3;
    }
}
