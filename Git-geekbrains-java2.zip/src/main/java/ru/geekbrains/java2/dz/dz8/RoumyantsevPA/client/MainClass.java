package ru.geekbrains.java2.dz.dz8.RoumyantsevPA.client;

public class MainClass {
    public static void main(String[] args) {
        MyWindow w = new MyWindow();
    }
}
