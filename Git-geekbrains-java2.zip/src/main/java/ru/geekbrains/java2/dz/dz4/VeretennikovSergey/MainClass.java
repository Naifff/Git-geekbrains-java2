package ru.geekbrains.java2.dz.dz4.VeretennikovSergey;

public class MainClass {
    public static void main(String[] args) {
        new MyWindows();
    }
}
