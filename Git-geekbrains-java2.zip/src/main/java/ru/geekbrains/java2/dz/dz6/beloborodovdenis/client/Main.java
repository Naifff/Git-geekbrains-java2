package ru.geekbrains.java2.dz.dz6.beloborodovdenis.client;

public class Main {
    public static void main(String[] args) {
        ClientChat cc = new ClientChat();
        cc.startClient();
    }
}
