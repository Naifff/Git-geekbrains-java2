package ru.geekbrains.java2.dz.dz6.AndreyMurzin;

public class StartServer {
    public static void main(String[] args) {
        Server.StartServer();
    }
}
