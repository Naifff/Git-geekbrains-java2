package ru.geekbrains.java2.dz4.AndreyMurzin;

public class MainClass {
    public static void main(String[] args) {
        new MyWindow();

    }
}
