package ru.geekbrains.java2.dz.dz4.NikitaKremlev;

public class ChatGUI {
    public static void main(String... args) {
        new FormChat();
    }

}
