package ru.geekbrains.java2.dz.dz2.RustamMuftakhov;

public class MyArraySizeException extends Exception {

}
