package ru.geekbrains.java2.dz.dz7.lobysheva.client;

/*
 * Created by Oxana Lobysheva on 09/12/2017.
 */

public class RunChat {

    public static void main(String[] arg){

        new ChatRoomFrame();

    }
}
