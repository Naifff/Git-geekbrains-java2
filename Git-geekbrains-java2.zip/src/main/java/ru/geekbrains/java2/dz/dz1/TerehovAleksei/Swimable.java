package ru.geekbrains.java2.dz.dz1.TerehovAleksei;

public interface Swimable {
    void Swim(int distance);
}
