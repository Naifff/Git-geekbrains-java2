package ru.geekbrains.java2.dz.dz7.AlinaZhirova.client;

public class Main {

    public static void main(String[] args) {
        MyWindow clientWindow = new MyWindow();
    }


}
