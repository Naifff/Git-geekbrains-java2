package ru.geekbrains.java2.dz.dz1.TerehovAleksei;

public interface Jumpable {
    void Jump(int height);
}
