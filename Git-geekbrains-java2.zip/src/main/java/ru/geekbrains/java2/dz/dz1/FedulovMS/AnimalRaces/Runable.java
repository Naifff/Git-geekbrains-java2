package ru.geekbrains.java2.dz.dz1.FedulovMS.AnimalRaces;

public interface Runable {
    boolean run(double dist);
}
