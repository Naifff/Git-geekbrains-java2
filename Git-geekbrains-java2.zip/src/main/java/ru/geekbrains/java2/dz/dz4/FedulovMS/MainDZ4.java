package ru.geekbrains.java2.dz.dz4.FedulovMS;

public class MainDZ4 {
    public static void main(String[] args) {
        ChatWindow cw = new ChatWindow();
    }
}
