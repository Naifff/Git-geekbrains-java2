package ru.geekbrains.java2.dz.dz1.Korolev_Sergey;

public interface Courses {
    void run();
    void jump();
   // void swim(double dist);
}
