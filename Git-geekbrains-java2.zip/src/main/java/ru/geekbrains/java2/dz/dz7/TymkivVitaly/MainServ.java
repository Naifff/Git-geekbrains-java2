package ru.geekbrains.java2.dz.dz7.TymkivVitaly;

public class MainServ {

    public static void main(String[] args) {
        Server server = new Server();
    }
}
