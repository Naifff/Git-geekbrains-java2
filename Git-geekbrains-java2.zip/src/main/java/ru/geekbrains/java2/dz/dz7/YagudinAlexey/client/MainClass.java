package ru.geekbrains.java2.dz.dz7.YagudinAlexey.client;

public class MainClass {
    public static void main(String[] args) {
        MyWindow w = new MyWindow();
    }
}
