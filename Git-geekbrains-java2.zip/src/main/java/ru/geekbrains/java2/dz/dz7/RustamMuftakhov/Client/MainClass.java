package ru.geekbrains.java2.dz.dz7.RustamMuftakhov.Client;

public class MainClass {
    public static void main(String[] args) {
        MyWindow w = new MyWindow();
    }
}
