package ru.geekbrains.java2.dz.dz4.RustamMuftakhov;

public class Main {

    public static void main(String[] args) {
	new ChatWindow();
    }
}
