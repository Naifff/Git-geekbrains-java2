package ru.geekbrains.java2.dz.dz4.KrivonosovAlexey;

public class main {
    public static void main(String[] args) {
        new Win();
    }
}
