package ru.geekbrains.java2.dz.dz1.TerehovAleksei;

public interface Runnable {
    void Run(int distance);
}
