package ru.geekbrains.java2.dz.dz1.TymkivVitaly;

interface Run {
    String run(int dist);
}
