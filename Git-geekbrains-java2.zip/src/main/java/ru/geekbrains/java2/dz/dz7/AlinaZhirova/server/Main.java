package ru.geekbrains.java2.dz.dz7.AlinaZhirova.server;

public class Main {

    public static void main(String[] args) {
        MyServer curServer = new MyServer();
    }


}
