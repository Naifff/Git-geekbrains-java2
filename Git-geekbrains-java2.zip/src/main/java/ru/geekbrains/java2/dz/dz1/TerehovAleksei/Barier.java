package ru.geekbrains.java2.dz.dz1.TerehovAleksei;

public interface Barier {
    void canBarier(Animal animal);
    void getInfo();
}
