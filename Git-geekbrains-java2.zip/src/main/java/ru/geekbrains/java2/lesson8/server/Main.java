package ru.geekbrains.java2.lesson8.server;

public class Main {
    public static void main(String[] args) {
        new MyServer(); // Создаем сервер
    }
}
