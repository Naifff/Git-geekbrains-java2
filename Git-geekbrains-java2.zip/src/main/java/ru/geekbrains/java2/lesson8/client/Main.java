package ru.geekbrains.java2.lesson8.client;

public class Main {
    public static void main(String[] args) {
        new MyWindow();
    }
}
